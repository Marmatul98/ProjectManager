package com.company;

import org.testng.Assert;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

public class KeyValueFormatterTest {

    @Test
    public void testFormat() {
        MobilePhone testMobilePhone = new MobilePhone();
        testMobilePhone.setWeightInGrams(400);
        testMobilePhone.setMemoryCardFlag(true);
        testMobilePhone.setManufacturer("Apple");
        testMobilePhone.setOperatingSystem(OperatingSystem.IOS);
        testMobilePhone.setRamInMegabytes(4000);
        testMobilePhone.setBatteryCapacityInmAh(6000);
        testMobilePhone.setBluetoothFlag(true);
        testMobilePhone.setNfcFlag(false);
        testMobilePhone.setAntutuScore(11000);
        testMobilePhone.setDisplaySizeInInches(5.8);

        String expected = "WeightInGrams:400\n" +
                "MemoryCardFlag:true\n" +
                "Manufacturer:\"Apple\"\n" +
                "OperatingSystem:IOS\n" +
                "RamInMegabytes:4000\n" +
                "BatteryCapacityInmAh:6000\n" +
                "BluetoothFlag:true\n" +
                "NfcFlag:false\n" +
                "AntutuScore:11000\n" +
                "DisplaySizeInInches:5.8";
        String actual = KeyValueFormatter.format(testMobilePhone);

        Assert.assertEquals(actual, expected);
    }

    @Test
    public void testParse() {
        String formattedString = "WeightInGrams:400\n" +
                "MemoryCardFlag:true\n" +
                "Manufacturer:\"Apple\"\n" +
                "OperatingSystem:IOS\n" +
                "RamInMegabytes:4000\n" +
                "BatteryCapacityInmAh:6000\n" +
                "BluetoothFlag:true\n" +
                "NfcFlag:false\n" +
                "AntutuScore:11000\n" +
                "DisplaySizeInInches:5.8";

        MobilePhone expectedMobilePhone = new MobilePhone();
        expectedMobilePhone.setWeightInGrams(400);
        expectedMobilePhone.setMemoryCardFlag(true);
        expectedMobilePhone.setManufacturer("Apple");
        expectedMobilePhone.setOperatingSystem(OperatingSystem.IOS);
        expectedMobilePhone.setRamInMegabytes(4000);
        expectedMobilePhone.setBatteryCapacityInmAh(6000);
        expectedMobilePhone.setBluetoothFlag(true);
        expectedMobilePhone.setNfcFlag(false);
        expectedMobilePhone.setAntutuScore(11000);
        expectedMobilePhone.setDisplaySizeInInches(5.8);

        MobilePhone actualMobilePhone = KeyValueFormatter.parse(formattedString);

        Assert.assertEquals(actualMobilePhone, expectedMobilePhone);

    }

    @Test
    public void testNullObjectInParseMethod(){
        String nullString = null;
        try {
            KeyValueFormatter.parse(nullString);
            Assert.fail();
        } catch (IllegalArgumentException ignored){

        }
    }

    @Test
    public void testEmptyStringInParseMethod(){
        String emptyString = "   ";
        try {
            KeyValueFormatter.parse(emptyString);
            Assert.fail();
        } catch (IllegalArgumentException ignored){

        }
    }

    @Test
    public void testNullObjectInFormatMethod(){
        MobilePhone nullMobilePhone = null;
        try {
            KeyValueFormatter.format(nullMobilePhone);
            Assert.fail();
        } catch (IllegalArgumentException ignored){

        }
    }
}