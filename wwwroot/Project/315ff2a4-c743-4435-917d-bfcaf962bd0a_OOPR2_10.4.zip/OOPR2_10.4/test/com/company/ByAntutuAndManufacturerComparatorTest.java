package com.company;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ByAntutuAndManufacturerComparatorTest {
    @Test
    public void testAscendingOrder() {
        MobilePhone testPhone = new MobilePhone();
        testPhone.setAntutuScore(8000);
        testPhone.setManufacturer("A");
        MobilePhone testPhone2 = new MobilePhone();
        testPhone2.setAntutuScore(8000);
        testPhone2.setManufacturer("B");
        MobilePhone testPhone3 = new MobilePhone();
        testPhone3.setAntutuScore(10000);
        testPhone3.setManufacturer("C");
        MobilePhone testPhone4 = new MobilePhone();
        testPhone4.setAntutuScore(11000);
        testPhone4.setManufacturer("C");

        List<MobilePhone> testList = Arrays.asList(testPhone, testPhone2, testPhone3, testPhone4);

        Collections.sort(testList, new MobilePhone.ByAntutuAndManufacturerComparator());

        Assert.assertEquals(testList.get(0), testPhone);
        Assert.assertEquals(testList.get(1), testPhone2);
        Assert.assertEquals(testList.get(2), testPhone3);
        Assert.assertEquals(testList.get(3), testPhone4);
    }

    @Test
    public void testDescendingOrder() {
        MobilePhone testPhone = new MobilePhone();
        testPhone.setAntutuScore(8000);
        testPhone.setManufacturer("A");
        MobilePhone testPhone2 = new MobilePhone();
        testPhone2.setAntutuScore(8000);
        testPhone2.setManufacturer("B");
        MobilePhone testPhone3 = new MobilePhone();
        testPhone3.setAntutuScore(10000);
        testPhone3.setManufacturer("C");
        MobilePhone testPhone4 = new MobilePhone();
        testPhone4.setAntutuScore(11000);
        testPhone4.setManufacturer("C");

        List<MobilePhone> testList = Arrays.asList(testPhone, testPhone2, testPhone3, testPhone4);

        Collections.sort(testList, new MobilePhone.ByAntutuAndManufacturerComparator(
                MobilePhone.ByAntutuAndManufacturerComparator.Direction.descending));

        Assert.assertEquals(testList.get(0), testPhone4);
        Assert.assertEquals(testList.get(1), testPhone3);
        Assert.assertEquals(testList.get(2), testPhone2);
        Assert.assertEquals(testList.get(3), testPhone);
    }

}