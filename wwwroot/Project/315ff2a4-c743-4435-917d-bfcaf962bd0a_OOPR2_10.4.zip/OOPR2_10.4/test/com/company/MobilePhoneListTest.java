package com.company;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class MobilePhoneListTest {

    @Test
    public void addMethodTest() {
        MobilePhone testPhone = new MobilePhone();
        testPhone.setAntutuScore(6999);

        List<MobilePhone> mobilePhoneList = new MobilePhoneList();
        mobilePhoneList.add(testPhone);

        Assert.assertTrue(mobilePhoneList.isEmpty());
    }

    @Test
    public void setMethodTest() {
        MobilePhone testPhone = new MobilePhone();
        testPhone.setAntutuScore(6999);

        MobilePhone testPhone2 = new MobilePhone();
        testPhone2.setAntutuScore(7000);

        List<MobilePhone> mobilePhoneList = new MobilePhoneList();
        mobilePhoneList.add(testPhone2);

        mobilePhoneList.set(0, testPhone);

        Assert.assertEquals(mobilePhoneList.get(0), testPhone2);
    }

    @Test
    public void addAllMethodTest(){
        MobilePhone testPhone = new MobilePhone();
        testPhone.setAntutuScore(7001);

        MobilePhone testPhone2 = new MobilePhone();
        testPhone2.setAntutuScore(7000);

        List<MobilePhone> mobilePhoneList = new MobilePhoneList();
        mobilePhoneList.add(testPhone2);
        mobilePhoneList.add(testPhone);

        MobilePhone testPhone3 = new MobilePhone();
        testPhone3.setAntutuScore(7002);

        MobilePhone testPhone4 = new MobilePhone();
        testPhone4.setAntutuScore(6999);

        List<MobilePhone> mobilePhoneList2 = new ArrayList<>();
        mobilePhoneList2.add(testPhone3);
        mobilePhoneList2.add(testPhone4);

        mobilePhoneList.addAll(mobilePhoneList2);

        Assert.assertEquals(mobilePhoneList.size(), 3);
    }

    @Test
    public void invalidArgumentTestAddMethod(){
        List<MobilePhone> mobilePhoneList = new MobilePhoneList();
        try {
            mobilePhoneList.add(null);
            Assert.fail();
        }catch (IllegalArgumentException ignored){

        }
    }

    @Test
    public void invalidArgumentTestAddIndexMethod(){
        List<MobilePhone> mobilePhoneList = new MobilePhoneList();
        try {
            mobilePhoneList.add(0, null);
            Assert.fail();
        }catch (IllegalArgumentException ignored){

        }
    }

    @Test
    public void invalidArgumentTestSetMethod(){
        List<MobilePhone> mobilePhoneList = new MobilePhoneList();
        mobilePhoneList.add(new MobilePhone());
        try {
            mobilePhoneList.set(0,null);
            Assert.fail();
        }catch (IllegalArgumentException ignored){

        }
    }

    @Test
    public void invalidArgumentTestAddAllMethod(){
        List<MobilePhone> mobilePhoneList = new MobilePhoneList();
        List<MobilePhone> nullList = null;
        try {
            mobilePhoneList.addAll(nullList);
            Assert.fail();
        }catch (IllegalArgumentException ignored){

        }
    }

}