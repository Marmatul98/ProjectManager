package com.company;

import org.testng.Assert;
import org.testng.annotations.Test;

public class CsvFormatterTest {

    @Test
    public void testFormat() {
        MobilePhone testMobilePhone = new MobilePhone();
        testMobilePhone.setWeightInGrams(400);
        testMobilePhone.setMemoryCardFlag(true);
        testMobilePhone.setManufacturer("Apple");
        testMobilePhone.setOperatingSystem(OperatingSystem.IOS);
        testMobilePhone.setRamInMegabytes(4000);
        testMobilePhone.setBatteryCapacityInmAh(6000);
        testMobilePhone.setBluetoothFlag(true);
        testMobilePhone.setNfcFlag(false);
        testMobilePhone.setAntutuScore(11000);
        testMobilePhone.setDisplaySizeInInches(5.8);

        String expected = "400;true;\"Apple\";IOS;4000;6000;true;false;11000;5.8";
        String actual = CsvFormatter.format(testMobilePhone);

        Assert.assertEquals(actual, expected);
    }

    @Test
    public void testParse() {
        String formattedString = "400;true;\"Apple\";IOS;4000;6000;true;false;11000;5.8";

        MobilePhone expectedMobilePhone = new MobilePhone();
        expectedMobilePhone.setWeightInGrams(400);
        expectedMobilePhone.setMemoryCardFlag(true);
        expectedMobilePhone.setManufacturer("Apple");
        expectedMobilePhone.setOperatingSystem(OperatingSystem.IOS);
        expectedMobilePhone.setRamInMegabytes(4000);
        expectedMobilePhone.setBatteryCapacityInmAh(6000);
        expectedMobilePhone.setBluetoothFlag(true);
        expectedMobilePhone.setNfcFlag(false);
        expectedMobilePhone.setAntutuScore(11000);
        expectedMobilePhone.setDisplaySizeInInches(5.8);

        MobilePhone actualMobilePhone = CsvFormatter.parse(formattedString);

        Assert.assertEquals(actualMobilePhone, expectedMobilePhone);

    }

    @Test
    public void testNullObjectInParseMethod(){
        String nullString = null;
        try {
            CsvFormatter.parse(nullString);
            Assert.fail();
        } catch (IllegalArgumentException ignored){

        }
    }

    @Test
    public void testEmptyStringInParseMethod(){
        String emptyString = "   ";
        try {
            CsvFormatter.parse(emptyString);
            Assert.fail();
        } catch (IllegalArgumentException ignored){

        }
    }

    @Test
    public void testNullObjectInFormatMethod(){
        MobilePhone nullMobilePhone = null;
        try {
            CsvFormatter.format(nullMobilePhone);
            Assert.fail();
        } catch (IllegalArgumentException ignored){

        }
    }
}