package com.company;

import java.util.ArrayList;
import java.util.Collection;

public class MobilePhoneList extends ArrayList<MobilePhone> {

    private static final int MINIMAL_VALUE = 7000;

    public MobilePhoneList() {
    }

    public MobilePhoneList(Collection<? extends MobilePhone> c) {
        super();
        addAll(c);
    }

    @Override
    public MobilePhone set(int index, MobilePhone element) {
        if (element == null){
            throw new IllegalArgumentException();
        }
        if (element.getAntutuScore() >= MINIMAL_VALUE){
            super.set(index, element);
            return element;
        }
        return null;
    }

    @Override
    public boolean add(MobilePhone mobilePhone) {
        if (mobilePhone == null){
            throw new IllegalArgumentException();
        }
        if (mobilePhone.getAntutuScore() >= MINIMAL_VALUE) {
            super.add(mobilePhone);
            return true;
        }
        return false;
    }

    @Override
    public void add(int index, MobilePhone element) {
        if (element == null){
            throw new IllegalArgumentException();
        }
        if (element.getAntutuScore() >= MINIMAL_VALUE) {
            super.add(index, element);
        }
    }

    @Override
    public boolean addAll(Collection<? extends MobilePhone> c) {
        if (c == null || c.size() == 0){
            throw new IllegalArgumentException();
        }
        boolean ret = true;
        for (MobilePhone phone : c) {
            ret = this.add(phone);
        }
        return ret;
    }

    @Override
    public boolean addAll(int index, Collection<? extends MobilePhone> c) {
        if (c == null || c.size() == 0){
            throw new IllegalArgumentException();
        }
        int sizeAtTheBeginning = this.size();
        for (MobilePhone phone : c) {
            int sizeBefore = this.size();
            this.add(phone);
            if (this.size() != sizeBefore){
                index++;
            }
        }
        return sizeAtTheBeginning != this.size();
    }
}
