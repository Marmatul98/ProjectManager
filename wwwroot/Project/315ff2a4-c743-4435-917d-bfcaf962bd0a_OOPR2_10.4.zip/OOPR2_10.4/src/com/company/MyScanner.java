package com.company;

import java.util.Scanner;

public class MyScanner {
    private Scanner sc = new Scanner(System.in);
    private final static String INCORRECT_VALUE_MESSAGE = "Incorrect value, enter again: ";


    public int readInt() {
        int ret = 0;
        boolean isValid = false;
        while (!isValid) {
            try {
                ret = Integer.parseInt(sc.nextLine());
                isValid = true;
            } catch (Exception e) {
                System.out.println(INCORRECT_VALUE_MESSAGE);
            }
        }
        return ret;
    }

    //parseBoolean mi nefungovalo podle mych pozadavku, napr po zapsani 'asdasda' to vlozilo false misto aby vyhodilo vyjimku
    public boolean readBoolean() {
        boolean ret = false;
        switch (sc.nextLine().toLowerCase()) {
            case "true": {
                ret = true;
                break;
            }
            case "false": {
                break;
            }
            default: {
                System.out.println(INCORRECT_VALUE_MESSAGE);
                throw new IllegalArgumentException();
            }
        }
        return ret;
    }

    public double readDouble() {
        double ret = 0;
        boolean isValid = false;
        while (!isValid) {
            try {
                ret = Double.parseDouble(sc.nextLine());
                isValid = true;
            } catch (Exception e) {
                System.out.println(INCORRECT_VALUE_MESSAGE);
            }
        }
        return ret;
    }

    public String readString() {
        return sc.nextLine();
    }

    public OperatingSystem readOperatingSystem() {
        int operatingSystemNumber = readInt();

        switch (operatingSystemNumber) {
            case 1: {
                return OperatingSystem.ANDROID;
            }
            case 2: {
                return OperatingSystem.IOS;
            }
            default: {
                System.out.println(INCORRECT_VALUE_MESSAGE);
                readOperatingSystem();
            }
        }
        return null;
    }
}
