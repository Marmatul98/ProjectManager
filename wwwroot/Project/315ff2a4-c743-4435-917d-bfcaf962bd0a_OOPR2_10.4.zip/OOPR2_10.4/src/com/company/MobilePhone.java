package com.company;

import java.util.Comparator;
import java.util.Objects;

public class MobilePhone implements Comparable<MobilePhone> {
    //Vsechno ma setter, je to proto, protoze na cviceni jsme se bavili o tom, ze by bylo dobre, aby byla moznost opraveni chyby

    private int weightInGrams;
    private boolean memoryCardFlag;
    private String manufacturer;
    private OperatingSystem operatingSystem;
    private int ramInMegabytes;
    private int batteryCapacityInmAh;
    private boolean bluetoothFlag;
    private boolean nfcFlag;
    private int antutuScore;
    private double displaySizeInInches;

    public static class ByAntutuAndManufacturerComparator implements Comparator<MobilePhone>{
        private final Direction direction;

        public enum Direction{
            ascending,
            descending
        }

        public ByAntutuAndManufacturerComparator() {
            this.direction = Direction.ascending;
        }

        public ByAntutuAndManufacturerComparator(Direction direction){
            this.direction = direction;
        }

        @Override
        public int compare(MobilePhone o1, MobilePhone o2) {
            int antutuCompare = Integer.compare(o1.getAntutuScore(), o2.getAntutuScore());
            int manufacturerCompare = antutuCompare;
            if (antutuCompare == 0){
                manufacturerCompare = o1.getManufacturer().compareTo(o2.getManufacturer());
            }
            return direction.equals(Direction.ascending) ? manufacturerCompare : -manufacturerCompare;
        }
    }


    public void setWeightInGrams(int weightInGrams) {
        if (weightInGrams < 100 || weightInGrams > 500) {
            throw new IllegalArgumentException("Weight in grams must be between 100 and 500!");
        } else {
            this.weightInGrams = weightInGrams;
        }
    }

    public void setMemoryCardFlag(boolean memoryCardFlag) {
        this.memoryCardFlag = memoryCardFlag;
    }

    public void setManufacturer(String manufacturer) {
        if (manufacturer.length() == 0 || manufacturer.length() > 75) {
            throw new IllegalArgumentException("Manufacturer name must consist of 1 to 75 characters!");
        } else {
            this.manufacturer = manufacturer;
        }
    }

    public void setOperatingSystem(OperatingSystem operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public void setRamInMegabytes(int ramInMegabytes) {
        if (ramInMegabytes < 2000 || ramInMegabytes > 15000) {
            throw new IllegalArgumentException("Ram in megabytes must be between 2000 and 15000!");
        } else {
            this.ramInMegabytes = ramInMegabytes;
        }
    }

    public void setBatteryCapacityInmAh(int batteryCapacityInmAh) {
        if (batteryCapacityInmAh < 2000 || batteryCapacityInmAh > 10000) {
            throw new IllegalArgumentException("Battery Capacity In mAh must be between 2000 and 10000!");
        } else {
            this.batteryCapacityInmAh = batteryCapacityInmAh;
        }
    }

    public void setBluetoothFlag(boolean bluetoothFlag) {
        this.bluetoothFlag = bluetoothFlag;
    }

    public void setNfcFlag(boolean nfcFlag) {
        this.nfcFlag = nfcFlag;
    }

    public void setAntutuScore(int antutuScore) {
        if (antutuScore < 6000 || antutuScore > 55000) {
            throw new IllegalArgumentException("Antutu score must be between 6000 and 55000!");
        } else {
            this.antutuScore = antutuScore;
        }
    }

    public void setDisplaySizeInInches(double displaySizeInInches) {
        if (displaySizeInInches < 4 || displaySizeInInches > 9) {
            throw new IllegalArgumentException("Display size in inches must be between 4 and 9!");
        } else {
            this.displaySizeInInches = displaySizeInInches;
        }
    }

    public int getWeightInGrams() {
        return weightInGrams;
    }

    public boolean isMemoryCardFlag() {
        return memoryCardFlag;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public OperatingSystem getOperatingSystem() {
        return operatingSystem;
    }

    public int getRamInMegabytes() {
        return ramInMegabytes;
    }

    public int getBatteryCapacityInmAh() {
        return batteryCapacityInmAh;
    }

    public boolean isBluetoothFlag() {
        return bluetoothFlag;
    }

    public boolean isNfcFlag() {
        return nfcFlag;
    }

    public int getAntutuScore() {
        return antutuScore;
    }

    public double getDisplaySizeInInches() {
        return displaySizeInInches;
    }

    @Override
    public String toString() {
        return "MobilePhone{" +
                "weightInGrams=" + weightInGrams +
                ", memoryCardFlag=" + memoryCardFlag +
                ", manufacturer='" + manufacturer + '\'' +
                ", operatingSystem=" + operatingSystem +
                ", ramInMegabytes=" + ramInMegabytes +
                ", batteryCapacityInmAh=" + batteryCapacityInmAh +
                ", bluetoothFlag=" + bluetoothFlag +
                ", nfcFlag=" + nfcFlag +
                ", antutuScore=" + antutuScore +
                ", displaySizeInInches=" + displaySizeInInches +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MobilePhone that = (MobilePhone) o;
        return weightInGrams == that.weightInGrams &&
                memoryCardFlag == that.memoryCardFlag &&
                ramInMegabytes == that.ramInMegabytes &&
                batteryCapacityInmAh == that.batteryCapacityInmAh &&
                bluetoothFlag == that.bluetoothFlag &&
                nfcFlag == that.nfcFlag &&
                antutuScore == that.antutuScore &&
                Double.compare(that.displaySizeInInches, displaySizeInInches) == 0 &&
                Objects.equals(manufacturer, that.manufacturer) &&
                operatingSystem == that.operatingSystem;
    }

    @Override
    public int hashCode() {
        return Objects.hash(weightInGrams, memoryCardFlag, manufacturer, operatingSystem, ramInMegabytes, batteryCapacityInmAh, bluetoothFlag, nfcFlag, antutuScore, displaySizeInInches);
    }

    @Override
    public int compareTo(MobilePhone o) {
        return Integer.compare(this.antutuScore, o.getAntutuScore());
    }
}
