package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        //Pro jednoduchost a rozpoznatelnost objektu je vyplneny a sledovany pouze atribut 'Manufacturer'

        MobilePhone phoneNumberOne = new MobilePhone();
        phoneNumberOne.setManufacturer("Xiaomi");
        phoneNumberOne.setAntutuScore(8000);
        MobilePhone phoneNumberTwo = new MobilePhone();
        phoneNumberTwo.setAntutuScore(8000);
        phoneNumberTwo.setManufacturer("Samsung");
        MobilePhone phoneNumberThree = new MobilePhone();
        phoneNumberThree.setManufacturer("Apple");
        phoneNumberThree.setAntutuScore(9000);
        MobilePhone phoneNumberFour = new MobilePhone();
        phoneNumberFour.setManufacturer("Huawei");
        phoneNumberFour.setAntutuScore(11000);
        MobilePhone phoneNumberFive = new MobilePhone();
        phoneNumberFive.setManufacturer("Aligator");
        phoneNumberFive.setAntutuScore(7000);

        List<MobilePhone> mobilePhoneList = Arrays.asList(phoneNumberOne, phoneNumberTwo, phoneNumberThree, phoneNumberFour, phoneNumberFive);
        MobilePhone[] mobilePhoneArray = mobilePhoneList.stream().toArray(m -> new MobilePhone[m]);
        mobilePhoneList = Arrays.asList(mobilePhoneArray);


        System.out.println("Neserazeny");
        Collections.shuffle(mobilePhoneList);
        printManufacturersOfMobilePhoneList(mobilePhoneList);

        System.out.println();

        System.out.println("Serazeny nativne");
        Collections.sort(mobilePhoneList);
        printManufacturersOfMobilePhoneList(mobilePhoneList);

        System.out.println();

        System.out.println("Neserazeny");
        Collections.shuffle(mobilePhoneList);
        printManufacturersOfMobilePhoneList(mobilePhoneList);

        System.out.println();

        System.out.println("Serazeny comparatorem vzestupne");
        Collections.sort(mobilePhoneList, new MobilePhone.ByAntutuAndManufacturerComparator());
        printManufacturersOfMobilePhoneList(mobilePhoneList);

        System.out.println();

        System.out.println("Serazeny comparatorem sestupne");
        Collections.sort(mobilePhoneList, new MobilePhone.ByAntutuAndManufacturerComparator(
                MobilePhone.ByAntutuAndManufacturerComparator.Direction.descending));
        printManufacturersOfMobilePhoneList(mobilePhoneList);


        MobilePhone testPhone = new MobilePhone();
        phoneNumberFive.setManufacturer("TestPhone");
        phoneNumberFive.setAntutuScore(6999);

        System.out.println();

        List<MobilePhone> myList = new MobilePhoneList();
        myList.add(phoneNumberOne);
        myList.add(phoneNumberTwo);
        myList.add(testPhone);
        for (MobilePhone mobilePhone : myList) {
            System.out.println(mobilePhone);
        }


    }

    private static void printManufacturersOfMobilePhoneList(List<MobilePhone> mobilePhoneList) {
        for (MobilePhone mobilePhone : mobilePhoneList) {
            System.out.println(mobilePhone.getManufacturer() + " " + mobilePhone.getAntutuScore());
        }
    }
}
