package com.company;

public enum OperatingSystem {
    ANDROID("android"),
    IOS("ios");

    private String stringValue;

    OperatingSystem(String stringValue){
        this.stringValue = stringValue;
    }

    public static OperatingSystem getOperatingSystemByStringValue(String stringValue){
        for (OperatingSystem operatingSystem : values()) {
            if (stringValue.equalsIgnoreCase(operatingSystem.stringValue)){
                return operatingSystem;
            }
        }
        return null;
    }
}
