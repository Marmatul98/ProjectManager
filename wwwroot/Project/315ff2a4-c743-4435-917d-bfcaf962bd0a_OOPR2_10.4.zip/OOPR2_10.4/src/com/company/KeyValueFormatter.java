package com.company;

public class KeyValueFormatter {
    public static String format(MobilePhone mobilePhone) {
        if (mobilePhone == null) throw new IllegalArgumentException();

        return "WeightInGrams:" + mobilePhone.getWeightInGrams() + "\n" +
                "MemoryCardFlag:" + mobilePhone.isMemoryCardFlag() + "\n" +
                "Manufacturer:" + "\"" + mobilePhone.getManufacturer() + "\"" + "\n" +
                "OperatingSystem:" + mobilePhone.getOperatingSystem() + "\n" +
                "RamInMegabytes:" + mobilePhone.getRamInMegabytes() + "\n" +
                "BatteryCapacityInmAh:" + mobilePhone.getBatteryCapacityInmAh() + "\n" +
                "BluetoothFlag:" + mobilePhone.isBluetoothFlag() + "\n" +
                "NfcFlag:" + mobilePhone.isNfcFlag() + "\n" +
                "AntutuScore:" + mobilePhone.getAntutuScore() + "\n" +
                "DisplaySizeInInches:" + mobilePhone.getDisplaySizeInInches();
    }

    public static MobilePhone parse(String keyValue) {
        if (keyValue == null || keyValue.trim().equals("")) throw new IllegalArgumentException();
        MobilePhone returnedMobilePhone = new MobilePhone();

        String[] splittedKeyValue = keyValue.split("\n");
        returnedMobilePhone.setWeightInGrams(Integer.valueOf(splittedKeyValue[0].substring(splittedKeyValue[0].indexOf(":") + 1)));
        returnedMobilePhone.setMemoryCardFlag(Boolean.valueOf(splittedKeyValue[1].substring(splittedKeyValue[1].indexOf(":") + 1)));
        returnedMobilePhone.setManufacturer(
                splittedKeyValue[2].substring(splittedKeyValue[0].indexOf(":") + 1).replace("\"", ""));
        returnedMobilePhone.setOperatingSystem(
                OperatingSystem.getOperatingSystemByStringValue(splittedKeyValue[3].substring(splittedKeyValue[3].indexOf(":") + 1)));
        returnedMobilePhone.setRamInMegabytes(Integer.valueOf(splittedKeyValue[4].substring(splittedKeyValue[4].indexOf(":") + 1)));
        returnedMobilePhone.setBatteryCapacityInmAh(Integer.valueOf(splittedKeyValue[5].substring(splittedKeyValue[5].indexOf(":") + 1)));
        returnedMobilePhone.setBluetoothFlag(Boolean.valueOf(splittedKeyValue[6].substring(splittedKeyValue[6].indexOf(":") + 1)));
        returnedMobilePhone.setNfcFlag(Boolean.valueOf(splittedKeyValue[7].substring(splittedKeyValue[7].indexOf(":") + 1)));
        returnedMobilePhone.setAntutuScore(Integer.valueOf(splittedKeyValue[8].substring(splittedKeyValue[8].indexOf(":") + 1)));
        returnedMobilePhone.setDisplaySizeInInches(Double.valueOf(splittedKeyValue[9].substring(splittedKeyValue[9].indexOf(":") + 1)));

        return returnedMobilePhone;
    }
}
