package com.company;

public class MobilePhoneInitializer {
    private static final MyScanner scanner = new MyScanner();

    public static MobilePhone initializeMobilePhoneFromUserByScanner() {
        MobilePhone mobilePhone = new MobilePhone();
        initWeightInGramsAndSetItToMobilePhone(mobilePhone);
        initMemoryCardFlagAndSetItToMobilePhone(mobilePhone);
        initManufacturerAndSetItToMobilePhone(mobilePhone);
        initOperatingSystemAndSetItToMobilePhone(mobilePhone);
        initRamInMegabytesAndSetItToMobilePhone(mobilePhone);
        initBatteryCapacityInmAhAndSetItToMobilePhone(mobilePhone);
        initBluetoothFlagAndSetItToMobilePhone(mobilePhone);
        initNfcFlagAndSetItToMobilePhone(mobilePhone);
        initAntutuScoreAndSetItToMobilePhone(mobilePhone);
        initDisplaySizeInInchesAndSetItToMobilePhone(mobilePhone);
        return mobilePhone;
    }

    private static void initWeightInGramsAndSetItToMobilePhone(MobilePhone mobilePhone) {
        System.out.println("Write weight in grams");
        int readInt = scanner.readInt();
        try {
            mobilePhone.setWeightInGrams(readInt);
        } catch (IllegalArgumentException e) {
            System.out.println("Weight must be between 100 and 500!");
            initWeightInGramsAndSetItToMobilePhone(mobilePhone);
        }
    }

    private static void initMemoryCardFlagAndSetItToMobilePhone(MobilePhone mobilePhone) {
        System.out.println("Does the mobile phone have memory card ? Write true or false");
        try {
            boolean readBoolean = scanner.readBoolean();
            mobilePhone.setMemoryCardFlag(readBoolean);
        } catch (IllegalArgumentException e) {
            System.out.println("Write true or false!");
            initMemoryCardFlagAndSetItToMobilePhone(mobilePhone);
        }
    }

    private static void initManufacturerAndSetItToMobilePhone(MobilePhone mobilePhone) {
        System.out.println("Write manufacturer");
        String readString = scanner.readString();
        try {
            mobilePhone.setManufacturer(readString);
        } catch (IllegalArgumentException e) {
            System.out.println("Manufacturer name must consist of 1 to 75 characters");
            initManufacturerAndSetItToMobilePhone(mobilePhone);
        }
    }

    private static void initOperatingSystemAndSetItToMobilePhone(MobilePhone mobilePhone) {
        System.out.println("Choose operating system - 1 for Android; 2 for iOS");
        mobilePhone.setOperatingSystem(scanner.readOperatingSystem());
    }

    private static void initRamInMegabytesAndSetItToMobilePhone(MobilePhone mobilePhone) {
        System.out.println("Write ram in megabytes");
        int readInt = scanner.readInt();
        try {
            mobilePhone.setRamInMegabytes(readInt);
        } catch (IllegalArgumentException e) {
            System.out.println("Ram must be between 2000 and 15000");
            initRamInMegabytesAndSetItToMobilePhone(mobilePhone);
        }
    }

    private static void initBatteryCapacityInmAhAndSetItToMobilePhone(MobilePhone mobilePhone) {
        System.out.println("Write battery capacity in mAh");
        int readInt = scanner.readInt();
        try {
            mobilePhone.setBatteryCapacityInmAh(readInt);
        } catch (IllegalArgumentException e) {
            System.out.println("Battery capacity in mAh must be between 2000 and 10000");
            initRamInMegabytesAndSetItToMobilePhone(mobilePhone);
        }
    }

    private static void initBluetoothFlagAndSetItToMobilePhone(MobilePhone mobilePhone) {
        System.out.println("Does the mobile phone have bluetooth ? Write true or false");
        try {
            boolean readBoolean = scanner.readBoolean();
            mobilePhone.setBluetoothFlag(readBoolean);
        } catch (IllegalArgumentException e) {
            System.out.println("Write true or false!");
            initBluetoothFlagAndSetItToMobilePhone(mobilePhone);
        }
    }

    private static void initNfcFlagAndSetItToMobilePhone(MobilePhone mobilePhone) {
        System.out.println("Does the mobile phone have nfc ? Write true or false");
        try {
            boolean readBoolean = scanner.readBoolean();
            mobilePhone.setNfcFlag(readBoolean);
        } catch (IllegalArgumentException e) {
            System.out.println("Write true or false!");
            initNfcFlagAndSetItToMobilePhone(mobilePhone);
        }
    }

    private static void initAntutuScoreAndSetItToMobilePhone(MobilePhone mobilePhone) {
        System.out.println("Write antutu score");
        int readInt = scanner.readInt();
        try {
            mobilePhone.setAntutuScore(readInt);
        } catch (IllegalArgumentException e) {
            System.out.println("Antutu score must be between 6000 and 55000");
            initAntutuScoreAndSetItToMobilePhone(mobilePhone);
        }
    }

    private static void initDisplaySizeInInchesAndSetItToMobilePhone(MobilePhone mobilePhone) {
        System.out.println("Write display size in inches");
        double readDouble = scanner.readDouble();
        try {
            mobilePhone.setDisplaySizeInInches(readDouble);
        } catch (IllegalArgumentException e) {
            System.out.println("Display size in inches must be between 4 and 9!");
            initDisplaySizeInInchesAndSetItToMobilePhone(mobilePhone);
        }
    }
}
