package com.company;

public class CsvFormatter {

    public static String format(MobilePhone mobilePhone) {
        if (mobilePhone == null) throw new IllegalArgumentException();

        return mobilePhone.getWeightInGrams() + ";"
                + mobilePhone.isMemoryCardFlag() + ";"
                + "\"" + mobilePhone.getManufacturer() + "\"" + ";"
                + mobilePhone.getOperatingSystem() + ";"
                + mobilePhone.getRamInMegabytes() + ";"
                + mobilePhone.getBatteryCapacityInmAh() + ";"
                + mobilePhone.isBluetoothFlag() + ";"
                + mobilePhone.isNfcFlag() + ";"
                + mobilePhone.getAntutuScore() + ";"
                + mobilePhone.getDisplaySizeInInches();
    }

    public static MobilePhone parse(String csv){
        if (csv == null || csv.trim().equals("")) throw new IllegalArgumentException();
        MobilePhone returnedMobilePhone = new MobilePhone();

        String[] splittedCsv = csv.split(";");
        returnedMobilePhone.setWeightInGrams(Integer.valueOf(splittedCsv[0]));
        returnedMobilePhone.setMemoryCardFlag(Boolean.valueOf(splittedCsv[1]));
        returnedMobilePhone.setManufacturer(splittedCsv[2].replace("\"", ""));
        returnedMobilePhone.setOperatingSystem(OperatingSystem.getOperatingSystemByStringValue(splittedCsv[3]));
        returnedMobilePhone.setRamInMegabytes(Integer.valueOf(splittedCsv[4]));
        returnedMobilePhone.setBatteryCapacityInmAh(Integer.valueOf(splittedCsv[5]));
        returnedMobilePhone.setBluetoothFlag(Boolean.valueOf(splittedCsv[6]));
        returnedMobilePhone.setNfcFlag(Boolean.valueOf(splittedCsv[7]));
        returnedMobilePhone.setAntutuScore(Integer.valueOf(splittedCsv[8]));
        returnedMobilePhone.setDisplaySizeInInches(Double.valueOf(splittedCsv[9]));

        return returnedMobilePhone;
    }
}
